<?php

/*
| Copy the returned 'aponbasket' array item into the existing top-level
| 'shop' array in config/themes.php. Do not replace the full config file.
| Intended for the Bagisto 2.4.x theme registry structure.
*/

use Webkul\Theme\Enums\SectionTypeEnum;

return [
    'aponbasket' => [
        'name'        => 'AponBasket Organic',
        'assets_path' => 'public/themes/shop/aponbasket',
        'views_path'  => 'resources/themes/aponbasket/views',
        'parent'      => 'default',
        'vite'        => [
            'hot_file'                 => 'shop-default-vite.hot',
            'build_directory'          => 'themes/shop/default/build',
            'package_assets_directory' => 'src/Resources/assets',
        ],
        'customize'   => [
            'sections' => [
                SectionTypeEnum::IMAGE_CAROUSEL,
                SectionTypeEnum::PRODUCT_CAROUSEL,
                SectionTypeEnum::CATEGORY_CAROUSEL,
                SectionTypeEnum::FOOTER_LINKS,
                SectionTypeEnum::STATIC_CONTENT,
            ],
        ],
    ],
];
