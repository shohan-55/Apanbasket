# AponBasket Organic — Bagisto storefront theme

এই প্যাকেজটি AponBasket-এর organic/natural grocery storefront-এর জন্য তৈরি। রেফারেন্স ছবির green + cream palette, ঘি, হলুদ, মরিচ গুঁড়া ও সরিষার তেলের campaign visuals ব্যবহার করা হয়েছে। Existing Bagisto catalog, search, cart, customer account, product detail ও checkout flow রাখা হয়েছে; core package file edit করা হয় না।

## কী আছে

- Bangla-first responsive homepage hero, promotional category tiles, trust strip, product/category carousel এবং brand story section
- Bagisto-এর active catalog API ব্যবহার করে category ও product carousel
- Header, product cards, buttons, form fields, service strip ও footer-এর সবুজ/ক্রিম visual treatment
- পূর্ণ leaf-bowl icon + AponBasket wordmark + tagline-সহ SVG logo; CSS দিয়ে Bagisto header-এর stock text/logo-এর জায়গায় স্বয়ংক্রিয়ভাবে দেখানোর নিয়ম
- আপনার দেওয়া চারটি campaign image — theme asset path-এ কপি করা আছে
- Standalone design preview: `preview/index.html`; preview screenshots: `preview/desktop-preview.jpg` এবং `preview/mobile-preview.jpg`

## গুরুত্বপূর্ণ compatibility note

Theme-এর layout override Bagisto **2.4.x storefront layout structure** ধরে তৈরি। Live site-এর exact Bagisto version এই প্যাকেজ তৈরির সময় নির্ধারণ করা যায়নি। তাই live site-এ apply করার আগে `composer show bagisto/bagisto` / project-এর composer files দেখে version মিলিয়ে নিন এবং মূল layout backup রাখুন। 2.3.x বা অন্য minor release হলে নিচে উল্লেখিত layout merge ধাপ ব্যবহার করুন।

## Installation (Bagisto 2.4.x theme registry)

1. প্রথমে আপনার Bagisto project root এবং `config/themes.php` backup নিন।
2. ZIP extract করে `resources/` এবং `public/` folder আপনার Bagisto project root-এ merge/copy করুন। File manager/FTP ব্যবহার করলে directory path ঠিক রাখুন।
3. `config/themes.php`-তে existing top-level `shop` array-এর ভেতরে `config/themes-aponbasket.snippet.php` ফাইল থেকে return হওয়া `aponbasket` array item-টি copy করে যোগ করুন। **পুরো `themes.php` replace করবেন না** এবং existing `default`/`admin` entries অক্ষত রাখুন।
4. `php artisan optimize:clear` চালান।
5. Admin Panel → **Settings / Channels** (কিছু version-এ **Configure → Channels**) → আপনার storefront channel খুলে Theme হিসেবে **AponBasket Organic / `aponbasket`** নির্বাচন করুন। Save করুন। যদি theme selector-এ না আসে, `config/themes.php` syntax ও cache আবার পরীক্ষা করুন।
6. `https://aponbasket.com` খুলে desktop ও mobile দুটোতেই দেখুন। নতুন leaf-bowl SVG logo header-এ CSS-এর মাধ্যমে দেখানোর চেষ্টা করবে। আপনার Bagisto version-এর header markup আলাদা হলে Admin → Settings → Channels → storefront channel → Logo-তে `public/themes/shop/aponbasket/images/aponbasket-logo.svg` ফাইলের public URL সেট করুন। এরপর cache clear করুন।

### যদি `config/themes.php`-এর structure আলাদা হয়

কোনো existing key মুছবেন না। `shop`-এর theme registry layout local Bagisto version অনুযায়ী merge করতে হবে। এই প্যাকেজে `resources/themes/aponbasket/views/components/layouts/index.blade.php` একটি layout override; এটি মূল Bagisto 2.4 layout-এর কাছাকাছি। অন্য minor version হলে আপনার `packages/Webkul/Shop/src/Resources/views/components/layouts/index.blade.php`-এর markup রেখে কেবল এই stylesheet line যোগ করাই নিরাপদ:

```blade
<link rel="stylesheet" href="{{ asset('themes/shop/aponbasket/css/aponbasket.css') }}?v=1.0.0">
```

তারপর custom layout override-টি local version অনুযায়ী মিলিয়ে নিন। এইভাবে Bagisto core files edit করতে হবে না।

## Theme rollback

Admin channel-এর Theme আবার `Default` করে save করুন। দরকার হলে আগের `config/themes.php` restore করুন। Theme folder সরালেও original Bagisto package views ও catalog data পরিবর্তিত হয় না।

## Live catalog সেটআপ

Homepage-এ product carousel Bagisto API থেকে পণ্য আনে। তাই Admin Panel-এ পণ্য তৈরি/enable, stock, price, image ও channel assignment ঠিক থাকতে হবে। Category carousel দেখাতে category-গুলো enabled এবং storefront-এ assigned থাকতে হবে। চারটি promo tile সরাসরি `?query=` দিয়ে search page-এ যায়; আপনার product naming Bangla/English অনুযায়ী চাইলে ওই query strings `home/index.blade.php` ফাইলে বদলাতে পারবেন।

## Logo note

Theme CSS header-এর stock 131px image logo-কে `AponBasket` wordmark দিয়ে দেখানোর চেষ্টা করে (modern Chrome/Edge-এ `:has()` সমর্থনের মাধ্যমে)। সব browser-এ consistent graphical logo চাইলে provided `aponbasket-logo.svg`-টি Channel logo হিসেবে upload করুন; তখন CSS wordmark override সরিয়ে নিতে পারেন।

## File map

- `resources/themes/aponbasket/views/home/index.blade.php` — homepage
- `resources/themes/aponbasket/views/components/layouts/index.blade.php` — global stylesheet include and storefront layout
- `resources/themes/aponbasket/views/components/layouts/services.blade.php` — brand-relevant global service strip
- `public/themes/shop/aponbasket/css/aponbasket.css` — all theme styles
- `public/themes/shop/aponbasket/images/` — logo and campaign images
- `config/themes-aponbasket.snippet.php` — registry entry to merge
