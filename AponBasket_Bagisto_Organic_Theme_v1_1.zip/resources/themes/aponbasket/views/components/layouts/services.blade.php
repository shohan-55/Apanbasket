{!! view_render_event('bagisto.shop.layout.features.before') !!}

<section class="ab-global-services" aria-label="AponBasket shopping information">
    <div class="ab-global-services__inner">
        <div class="ab-global-service">
            <span aria-hidden="true">♧</span>
            <div><strong>প্রকৃতির কাছাকাছি পণ্য</strong><small>Natural pantry essentials, all in one place</small></div>
        </div>
        <div class="ab-global-service">
            <span aria-hidden="true">☷</span>
            <div><strong>স্পষ্ট পণ্যের বিবরণ</strong><small>Choose with the product details in view</small></div>
        </div>
        <div class="ab-global-service">
            <span aria-hidden="true">⌂</span>
            <div><strong>সহজ অনলাইন অর্ডার</strong><small>Browse, add to cart and order from home</small></div>
        </div>
    </div>
</section>

{!! view_render_event('bagisto.shop.layout.features.after') !!}
