@php
    $channel = core()->getCurrentChannel();
@endphp

@push('meta')
    <meta name="title" content="AponBasket | Natural & Organic Products" />
    <meta name="description" content="খাঁটি ঘি, সরিষার তেল ও বিশুদ্ধ মসলা—AponBasket থেকে প্রকৃতির কাছের খাবার আপনার ঘরে।" />
    <meta name="keywords" content="AponBasket, natural products, organic food, ghee, mustard oil, turmeric, chili powder, Bangladesh" />
@endPush

@push('scripts')
    @if (! empty($categories))
        <script>
            localStorage.setItem('categories', JSON.stringify(@json($categories)));
        </script>
    @endif
@endPush

<x-shop::layouts>
    <x-slot:title>
        AponBasket | Natural & Organic Products
    </x-slot>

    <div class="ab-storefront">
        <div class="ab-announcement">
            <span class="ab-announcement__leaf" aria-hidden="true">✦</span>
            প্রকৃতির কাছ থেকে আপনার পরিবারের জন্য খাঁটি খাবার
            <a href="{{ route('shop.search.index') }}">পণ্য দেখুন <span aria-hidden="true">→</span></a>
        </div>

        <section class="ab-hero" aria-labelledby="ab-hero-title">
            <div class="ab-hero__copy">
                <span class="ab-eyebrow"><span class="ab-eyebrow__dot"></span> APONBASKET · NATURAL & ORGANIC</span>
                <h1 id="ab-hero-title">প্রকৃতির খাঁটি স্বাদ,<br><em>আপনার পরিবারের</em> জন্য</h1>
                <p class="ab-hero__description">খাঁটি গাওয়া ঘি, ঘানি ভাঙা সরিষার তেল আর যত্নে তৈরি মসলা—বিশ্বস্ত উৎস থেকে বেছে নেওয়া প্রতিদিনের প্রয়োজনীয় পণ্য।</p>
                <div class="ab-hero__actions">
                    <a class="ab-button ab-button--primary" href="{{ route('shop.search.index') }}">সব পণ্য দেখুন <span aria-hidden="true">↗</span></a>
                    <a class="ab-button ab-button--quiet" href="#ab-our-promise">আমাদের অঙ্গীকার <span aria-hidden="true">↓</span></a>
                </div>
                <div class="ab-hero__proof">
                    <div class="ab-avatars" aria-hidden="true"><span>আ</span><span>প</span><span>ন</span></div>
                    <div><strong>প্রতিদিনের খাবারে আস্থার সঙ্গী</strong><small>Natural choices. Honest goodness.</small></div>
                </div>
            </div>
            <div class="ab-hero__art">
                <div class="ab-hero__halo"></div>
                <div class="ab-hero__image-frame">
                    <img src="{{ asset('themes/shop/aponbasket/images/gawa-ghee-promo.jpg') }}" alt="AponBasket home made gাওয়া ghee" fetchpriority="high">
                </div>
                <div class="ab-floating-note ab-floating-note--top"><span class="ab-leaf-icon" aria-hidden="true">✳</span><span><strong>Pure & Natural</strong><small>প্রকৃতির কাছাকাছি</small></span></div>
                <div class="ab-floating-note ab-floating-note--bottom"><span class="ab-check-icon" aria-hidden="true">✓</span><span><strong>ভালোবাসা দিয়ে বাছাই</strong><small>Everyday pantry essentials</small></span></div>
                <span class="ab-deco-leaf ab-deco-leaf--one" aria-hidden="true">❧</span>
                <span class="ab-deco-leaf ab-deco-leaf--two" aria-hidden="true">❧</span>
            </div>
        </section>

        <section class="ab-benefit-strip" id="ab-our-promise" aria-label="AponBasket promises">
            <div class="ab-benefit"><span class="ab-benefit__icon" aria-hidden="true">♧</span><div><strong>প্রাকৃতিক পছন্দ</strong><small>Nature-inspired essentials</small></div></div>
            <div class="ab-benefit"><span class="ab-benefit__icon" aria-hidden="true">♡</span><div><strong>যত্নে বাছাই করা</strong><small>Quality comes first</small></div></div>
            <div class="ab-benefit"><span class="ab-benefit__icon" aria-hidden="true">⌂</span><div><strong>ঘরে পৌঁছে দিন</strong><small>Convenient home delivery</small></div></div>
            <div class="ab-benefit"><span class="ab-benefit__icon" aria-hidden="true">✓</span><div><strong>বিশ্বস্ত কেনাকাটা</strong><small>A simple, secure checkout</small></div></div>
        </section>

        <section class="ab-section ab-category-shortcuts" aria-labelledby="ab-pantry-title">
            <div class="ab-section-heading">
                <div><span class="ab-kicker">THE EVERYDAY PANTRY</span><h2 id="ab-pantry-title">আপনার পছন্দের <em>খাঁটি পণ্য</em></h2><p>রান্নাঘরের পরিচিত উপকরণ, যত্নে বেছে নিন এক জায়গা থেকেই।</p></div>
                <a class="ab-text-link" href="{{ route('shop.search.index') }}">সব পণ্য দেখুন <span aria-hidden="true">→</span></a>
            </div>
            <div class="ab-promo-grid">
                <a class="ab-promo-card ab-promo-card--ghee" href="{{ route('shop.search.index', ['query' => 'ghee']) }}">
                    <img src="{{ asset('themes/shop/aponbasket/images/gawa-ghee-promo.jpg') }}" alt="খাঁটি গাওয়া ঘি" loading="lazy">
                    <span class="ab-promo-card__shade"></span><span class="ab-promo-card__copy"><small>RICH & TRADITIONAL</small><strong>খাঁটি গাওয়া ঘি</strong><span>পণ্য দেখুন ↗</span></span>
                </a>
                <a class="ab-promo-card ab-promo-card--turmeric" href="{{ route('shop.search.index', ['query' => 'turmeric']) }}">
                    <img src="{{ asset('themes/shop/aponbasket/images/turmeric-promo.jpg') }}" alt="হলুদ গুঁড়া" loading="lazy">
                    <span class="ab-promo-card__shade"></span><span class="ab-promo-card__copy"><small>GOLDEN GOODNESS</small><strong>হলুদ গুঁড়া</strong><span>পণ্য দেখুন ↗</span></span>
                </a>
                <a class="ab-promo-card ab-promo-card--chilli" href="{{ route('shop.search.index', ['query' => 'chili powder']) }}">
                    <img src="{{ asset('themes/shop/aponbasket/images/chilli-powder-promo.jpg') }}" alt="মরিচ গুঁড়া" loading="lazy">
                    <span class="ab-promo-card__shade"></span><span class="ab-promo-card__copy"><small>PURE SPICE, FULL FLAVOUR</small><strong>মরিচ গুঁড়া</strong><span>পণ্য দেখুন ↗</span></span>
                </a>
                <a class="ab-promo-card ab-promo-card--oil" href="{{ route('shop.search.index', ['query' => 'mustard oil']) }}">
                    <img src="{{ asset('themes/shop/aponbasket/images/mustard-oil-promo.jpg') }}" alt="ঘানি ভাঙা সরিষার তেল" loading="lazy">
                    <span class="ab-promo-card__shade"></span><span class="ab-promo-card__copy"><small>FROM SEED TO BOTTLE</small><strong>সরিষার তেল</strong><span>পণ্য দেখুন ↗</span></span>
                </a>
            </div>
        </section>

        <section class="ab-section ab-live-categories" aria-label="Browse product categories">
            <div class="ab-section-heading">
                <div><span class="ab-kicker">SHOP BY CATEGORY</span><h2>ক্যাটাগরি অনুযায়ী <em>কেনাকাটা</em></h2></div>
                <a class="ab-text-link" href="{{ route('shop.search.index') }}">সব ক্যাটাগরি <span aria-hidden="true">→</span></a>
            </div>
            <x-shop::categories.carousel
                title=""
                :src="route('shop.api.categories.index', [])"
                :navigation-link="route('shop.search.index')"
                aria-label="AponBasket product categories"
            />
        </section>

        <section class="ab-product-section" aria-label="Featured products">
            <div class="ab-product-section__top">
                <div><span class="ab-kicker">HANDPICKED FOR YOUR HOME</span><h2>আজকের পছন্দ, <em>আপনার রান্নাঘরের জন্য</em></h2><p>আপনার স্টোরের ক্যাটালগ থেকে নির্বাচিত পণ্য এখানে দেখানো হবে।</p></div>
                <a class="ab-button ab-button--outline" href="{{ route('shop.search.index') }}">সব পণ্য <span aria-hidden="true">→</span></a>
            </div>
            <x-shop::products.carousel
                title=""
                :src="route('shop.api.products.index', [])"
                :navigation-link="route('shop.search.index')"
                aria-label="Featured AponBasket products"
            />
        </section>

        <section class="ab-story-section">
            <div class="ab-story-section__visual">
                <img src="{{ asset('themes/shop/aponbasket/images/mustard-oil-promo.jpg') }}" alt="AponBasket pure mustard oil" loading="lazy">
                <div class="ab-story-stamp"><span aria-hidden="true">✳</span><strong>প্রকৃতির<br>বিশুদ্ধ ছোঁয়া</strong><small>APONBASKET</small></div>
            </div>
            <div class="ab-story-section__copy">
                <span class="ab-kicker">A LITTLE CLOSER TO NATURE</span>
                <h2>খাবারের প্রতিটি বাছাইয়ে থাকুক <em>আস্থার ছোঁয়া</em></h2>
                <p>AponBasket-এ আমরা চাই, আপনার প্রতিদিনের রান্নাঘরের প্রয়োজনীয় পণ্য খুঁজে পাওয়া হোক সহজ। ঘি, সরিষার তেল ও মসলার মতো পরিচিত উপকরণ—পরিষ্কার তথ্য ও সহজ কেনাকাটার অভিজ্ঞতাসহ এক জায়গায়।</p>
                <div class="ab-story-points"><span><i aria-hidden="true">✓</i> পণ্যের স্পষ্ট বিবরণ</span><span><i aria-hidden="true">✓</i> সহজ অর্ডার প্রক্রিয়া</span><span><i aria-hidden="true">✓</i> পরিবারের কথা ভেবে বাছাই</span></div>
                <a class="ab-button ab-button--primary" href="{{ route('shop.search.index') }}">কেনাকাটা শুরু করুন <span aria-hidden="true">↗</span></a>
            </div>
        </section>

        {{-- Optional sections added through Bagisto Appearance > Themes > Customize. --}}
        @foreach ($sections as $section)
            @php ($data = $section->options)
            @php ($marks = ($preview ?? false) && ! $section->getTypeInstance()?->rendersInLayout())

            @if ($marks)
                <div data-section-id="{{ $section->id }}" data-section-name="{{ $section->name }}">
            @endif

            @switch ($section->type)
                @case (\Webkul\Theme\Enums\SectionTypeEnum::IMAGE_CAROUSEL->value)
                    <x-shop::carousel
                        :options="$section->getTypeInstance()?->sanitize((array) $data) ?? $data"
                        aria-label="{{ trans('shop::app.home.index.image-carousel') }}"
                    />
                    @break
                @case (\Webkul\Theme\Enums\SectionTypeEnum::STATIC_CONTENT->value)
                    @if (! empty($data['css']))
                        @push('styles')
                            <style>{!! $data['css'] !!}</style>
                        @endpush
                    @endif
                    @if (! empty($data['html']))
                        {!! $data['html'] !!}
                    @endif
                    @break
                @case (\Webkul\Theme\Enums\SectionTypeEnum::CATEGORY_CAROUSEL->value)
                    <x-shop::categories.carousel
                        :title="$data['title'] ?? ''"
                        :src="route('shop.api.categories.index', $data['filters'] ?? [])"
                        :navigation-link="route('shop.search.index', $data['filters'] ?? [])"
                        aria-label="{{ trans('shop::app.home.index.categories-carousel') }}"
                    />
                    @break
                @case (\Webkul\Theme\Enums\SectionTypeEnum::PRODUCT_CAROUSEL->value)
                    <x-shop::products.carousel
                        :title="$data['title'] ?? ''"
                        :src="route('shop.api.products.index', $data['filters'] ?? [])"
                        :navigation-link="route('shop.search.index', $data['filters'] ?? [])"
                        aria-label="{{ trans('shop::app.home.index.product-carousel') }}"
                    />
                    @break
            @endswitch

            @if ($marks)
                </div>
            @endif
        @endforeach

        @if ($preview ?? false)
            @include('shop::home.preview-bridge')
        @endif

        <section class="ab-bottom-cta">
            <div><span class="ab-bottom-cta__spark" aria-hidden="true">✦</span><span class="ab-kicker">WELCOME TO APONBASKET</span><h2>আপনার রান্নাঘরের ভালো পছন্দগুলো <em>শুরু হোক এখানেই।</em></h2><p>প্রয়োজনীয় পণ্য খুঁজুন, আপনার পছন্দের জিনিস কার্টে যোগ করুন, অর্ডার সম্পন্ন করুন সহজেই।</p></div>
            <a class="ab-button ab-button--light" href="{{ route('shop.search.index') }}">এখনই পণ্য দেখুন <span aria-hidden="true">→</span></a>
        </section>
    </div>
</x-shop::layouts>
